import  java.io.*;

/**
 * Test driver for class <code>AudioFile</code>.
 *
 * @author  iCarnegie
 * @version  1.0.0
 * @see AudioFile
 */
public class TestAudioFile  {

	/* Standard output stream */
	private static PrintWriter  stdOut =
		new  PrintWriter(System.out, true);

	/* Standard error stream */
	private static PrintWriter  stdErr =
		new  PrintWriter(System.err, true);

	/**
	 * Displays a message in the standard error stream if the value specified
	 * by parameter <code>condition<code> is <code>false</code>.
	 *
	 * @param message  the error message.
	 * @param condition  the test condition.
	 */
	public static void assertTrue(String message, boolean condition) {

		if (! condition) {
			stdErr.print("** Test failure ");
			stdErr.println(message);
		}
	}
	
	/**
	 * Displays a message in the standard error stream.
	 *
	 * @param message  the error message.
	 */
	public static void fail(String message) {

		stdErr.print("** Test failure ");
		stdErr.println(message);

		System.exit(0);
	}

	/**
	 * Test driver for class <code>AudioFile</code>.
	 *
	 * @param args  not used.
	 */
	public static void  main(String[] args)  {

		stdOut.println("");
		stdOut.println("Testing class AudioFile...");

		String name = "file name";
		int duration = 120;
		
		AudioFile file = new AudioFile(name, duration);

		// Test class definition
		assertTrue("1: testing class definition",
				file instanceof MediaFile);

		// Test accessors
		assertTrue("2: testing method getName",
				name.equals(file.getName()));
		assertTrue("3: testing method getDuration",
				duration == file.getDuration());

		// Test method equals
		String nameOne = "file name one";
		int durationOne = 150;

		String nameTwo = "file name two";
		int durationTwo = 35;

		AudioFile fileOne =
			new AudioFile(nameOne, durationOne);
		AudioFile fileTwo =
			new AudioFile(nameOne, durationTwo);
		AudioFile fileThree =
			 new AudioFile(nameTwo, durationTwo);

		assertTrue("4: testing method equals",
			fileOne.equals(fileTwo));
		assertTrue("5: testing method equals",
			! fileOne.equals(fileThree));
			
		try {
			assertTrue("6: testing method equals",
				! fileOne.equals(new Object()));
		} catch (ClassCastException cce) {
			fail("7: testing method equals, " + cce.toString());
		}

		// Testing the use of method equals to compare strings
		// The names are the same but different String objects.
		AudioFile fileSameNameOne =
			new AudioFile(new String("same name"), 10);
		AudioFile fileSameNameTwo =
			new AudioFile(new String("same name"), 10);

		assertTrue("8: testing the use of method equals to compare strings",
			fileSameNameOne.equals(fileSameNameTwo));

		// Test method toString
		file = new AudioFile(name, duration);

		String result = name + "," + duration;

		assertTrue("9: testing method toString",
			result.equals(file.toString()));

		stdOut.println("done");
	}
}
